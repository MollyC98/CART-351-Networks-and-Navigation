import Phaser from './lib/phaser.js';
// import { SCENE_KEYS } from './scenes/scene-keys.js';
import { PreloadScene } from './scenes/preload-scene.js';
import { GameScene } from './scenes/game-scene.js'; // Import GameScene
import showSurvey from './survey.js';

window.onload = function(){

    document.querySelector("#play").addEventListener("click", function(e){
        e.preventDefault();
        showSurvey(startGame);
    })
   

function startGame() {
    // Hide the survey and start the game
    document.getElementById('survey').style.display = 'none';
    document.getElementById('game-container').style.display = 'block';  // Show game container


        const game = new Phaser.Game({
        type: Phaser.AUTO,
        scale: {
            parent: 'game-container',
            width: 500,
            height: 250,
            mode: Phaser.Scale.FIT,
            autoCenter: Phaser.Scale.CENTER_BOTH
        },
        scene: [PreloadScene,GameScene], // Only include scenes needed for gameplay
        physics: {
            default: 'arcade',
            arcade: {
                gravity: { y: 0, x: 0 },
                debug: false
            }
        },
       
    });


    // Add Phaser game scenes
    //game.scene.add('Preload', PreloadScene);

    // Start the Preload scene
    game.scene.start('PreloadScene');
}
}
