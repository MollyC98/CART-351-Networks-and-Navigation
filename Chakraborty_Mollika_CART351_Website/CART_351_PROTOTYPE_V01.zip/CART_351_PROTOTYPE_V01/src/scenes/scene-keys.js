
export const SCENE_KEYS = Object.freeze({
    PRELOAD_SCENE: 'PRELOAD_SCENE', // preload scene that loads asset
    GAME_SCENE: 'GAME_SCENE', // Add GAME_SCENE
    MAIN_MENU: 'MAIN_MENU', // adding main menu for start and instructions 
    SURVEY_SCENE: 'SURVEY_SCENE'// survey questions for the game 
});
